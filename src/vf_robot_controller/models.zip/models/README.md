# models/ — trained model artifacts

Each model family has its own subdirectory. Within each family, runs are
organised by name in isolated subdirectories so multiple trained models can
coexist without overwriting each other.

## Naming convention

Run folders follow `<channels>_<runtag>` where:

- `<channels>` is the channel set the model was trained on:
  - `v1` → channels_v1 (126 dims)
  - `v2` → channels_v2 (130 dims)
  - `v3` → channels_v3 (170 dims, full feature set)
- `<runtag>` is free-form: `manual_v1`, `seed0`, `run2_2026_05_20`, …

Example folder names: `v1_manual_v1`, `v3_seed0`, `v2_run2_2026_05_20`.

Why bake the channel set into the folder: collected HDF5s always store the
full v3 features, but trainers can slice down to v1 / v2 / v3. The folder
name records which slice the saved weights were trained on, so loading the
wrong-dim ONNX at runtime fails fast instead of silently mis-aligning
features.

## Directory layout

```
models/
  metacritic_raw_wt/          ← raw-critic cost training runs (no oracle QP)
    v1_manual_v1/
      meta_critic.onnx        consumed by metacritic_inference_node.py sidecar
      meta_critic.pt          PyTorch checkpoint
      feature_norm.json       normalisation stats (mean/std per feature dim)
      metadata.json           ONNX metadata (in_dim, channel_names, run_id …)
      training_log.csv        per-epoch loss history
      training_curve.png      loss curve figure
    v3_seed0/
      (same files)
    …

  metacritic_oracle_wt/       ← Phase-9 QP oracle-label training runs
    v1_manual_v1/
      (same files as raw)
    …

  imitation_wt/               ← behaviour cloning (vx, wz direct output)
    v1_manual_v1/
      imitation.onnx          consumed by imitation_inference_node.py sidecar
      imitation.pt
      feature_norm.json
      metadata.json
      training_log.csv
      training_curve.png
    …
```

Binary `.onnx` and `.pt` files are gitignored. `feature_norm.json`,
`metadata.json`, `training_log.csv`, and `training_curve.png` are committed
so the run is reproducible and auditable without re-running training.

## Selecting weights at launch

The active run folder is controlled by `vf_controller/model_defaults.py`
(comment / uncomment one block per family):

```python
DEFAULT_INFERENCE_TYPE    = "oracle"          # "raw" | "oracle"
DEFAULT_INFERENCE_WEIGHTS = "v1_manual_v1"    # run folder under metacritic_<type>_wt/
DEFAULT_IMITATION_WEIGHTS = "v1_manual_v1"    # run folder under imitation_wt/
```

To switch at launch time without editing the file:

```bash
# Inference: switch to a v3 oracle model
ros2 launch vf_robot_bringup bringup_launch.py \
    inference_model_type:=oracle  inference_weights:=v3_manual_v1

# Imitation: switch to a v3 imitation run
ros2 launch vf_robot_bringup bringup_launch.py \
    controller:=vf_imitationwt  imitation_weights:=v3_manual_v1

# Custom path (escape hatch — bypasses folder resolution)
ros2 launch vf_robot_bringup bringup_launch.py \
    onnx_path:=/abs/path/to/meta_critic.onnx
```

## Training scripts and output folders

| Script | Default `--parent-dir` | Output `<run-name>` shape |
|--------|------------------------|---------------------------|
| `train_raw_critics.py` | `models/metacritic_raw_wt/`    | `<channels>_<runtag>` |
| `train_inference.py`   | `models/metacritic_oracle_wt/` | `<channels>_<runtag>` |
| `train_imitation.py`   | `models/imitation_wt/`         | `<channels>_<runtag>` |

Pass `--channels v1|v2|v3` and `--run-name <runtag>` (the trainer prefixes
the channels). Each script fails immediately if the run folder already
exists — no silent overwrites.

## ONNX I/O signatures

| Model | Input name | Input shape | Output name | Output shape |
|-------|------------|-------------|-------------|--------------|
| `meta_critic.onnx` | `features` | `(1, D)` | `weights` | `(1, K)` |
| `imitation.onnx`   | `features` | `(1, D)` | `cmd_vel`  | `(1, 2)` |

`D` matches the `<channels>` prefix (126 / 130 / 170); `K` is the number
of critics (default 11 for vf_fixedwt.yaml).
